# Lisa Core

Основной сервер AI-бота на FastAPI.